<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\CategorySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Комментарии забаненных пользователей';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="category-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            // 'id_user',
            [
                'attribute' => 'id_user',
                'label' => 'Пользователь',
                'value' => function($data) { return $data->user->username; }
            ],
            // 'id_publication',
            [
                'attribute' => 'id_publication',
                'label' => 'Статья',
                'value' => function($data) { return $data->publication->title; }
            ],
            'comment',
            'date_placement',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
