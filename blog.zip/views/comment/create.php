<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Comment */

$this->title = 'Создание нового комментария';
$this->params['breadcrumbs'][] = ['label' => 'Все статьи', 'url' => ['publication/']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="comment-create">

    <?= $this->render('formcreate', [
        'model' => $model,
    ]) ?>

</div>
