<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Comment */
/* @var $form yii\widgets\ActiveForm */

$user = Yii::$app->user->identity->id;
$id = $_GET['id'];
?>

<div class="comment-form">
    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_user')->hiddenInput(['value' => $user])->label(false) ?>

    <?= $form->field($model, 'id_publication')->hiddenInput(['value' => $id])->label(false) ?>

    <?= $form->field($model, 'comment')->textArea(['maxlength' => true]) ?>

    <?= $form->field($model, 'date_placement')->input('date') ?>

    <div class="form-group">
        <?= Html::submitButton('Отправить', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
