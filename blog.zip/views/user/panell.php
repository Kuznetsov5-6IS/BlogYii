<?php
$dbh = new PDO('mysql:dbname=blog;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$sth = $dbh->prepare("SELECT * FROM `user` WHERE ban = 'Yes'");
$sth->execute();
$users = $sth->fetchAll();
foreach($users as $user) {
    echo $user['username'];
    echo '<a href="unban?id='.$user['id'].'"> Разбанить</a><br>';
}