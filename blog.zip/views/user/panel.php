<?php
$dbh = new PDO('mysql:dbname=blog;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$sth = $dbh->prepare("SELECT * FROM `user` WHERE ban = 'No'");
$sth->execute();
$users = $sth->fetchAll();
foreach($users as $user) {
    echo $user['username'];
    echo '<a href="updban?id='.$user['id'].'"> Забанить</a><br>';
}