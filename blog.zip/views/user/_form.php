<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="user-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'username')->textInput(['maxlength' => true, 'placeholder' => 'Логин']) ?>

    <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Пароль']) ?>

    <?= $form->field($model, 'firstname')->textInput(['maxlength' => true, 'placeholder' => 'Имя']) ?>

    <?= $form->field($model, 'lastname')->textInput(['maxlength' => true, 'placeholder' => 'Фамилия']) ?>

    <?= $form->field($model, 'birthday')->input('date') ?>

    <?= $form->field($model, 'ban')->hiddenInput(['value' => 'No'])->label(false) ?>

    <?= $form->field($model, 'admin')->hiddenInput()->label(false) ?>

    <div class="form-group">
        <?= Html::submitButton('Зарегистрироваться', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
