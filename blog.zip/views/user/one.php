<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

?>
<div class="user-index">

    <h1>Ваш профиль</h1>

    

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            // 'username',
            // [
            // 'attribute' => 'username',
            // 'label' => 'Логин',
            // 'value' => function($model) { return $model->username; }
            // ],
            // 'password',
            // [
            //     'attribute' => 'password',
            //     'label' => 'Пароль',
            //     'value' => function($model) { return $model->password; }
            // ],
            //'firstname',
            [
                'attribute' => 'firstname',
                'label' => 'Имя',
                'value' => function($model) { return $model->firstname; }
            ],
            // 'lastname',
            [
                'attribute' => 'lastname',
                'label' => 'Фамилия',
                'value' => function($model) { return $model->lastname; }
            ],
            // 'birthday',
            [
                'attribute' => 'birthday',
                'label' => 'Дата рождения',
                'value' => function($model) { return $model->birthday; }
            ],
            //'ban',
            //admin

            ['class' => 'yii\grid\ActionColumn', 'template' => '{view}'],
        ],
    ]); ?>


</div>
