<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\User */

$this->title = $model->firstname. ', Вы можете редактировать свои данные';
$this->params['breadcrumbs'][] = ['label' => 'Действия над профилем', 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Редактирование данных';
?>
<div class="user-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form__update', [
        'model' => $model,
    ]) ?>

</div>
