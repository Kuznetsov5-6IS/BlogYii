<?php
$dbh = new PDO('mysql:dbname=blog;host=localhost', 'root', 'root');
$sth = $dbh->prepare("SET NAMES UTF8");
$sth->execute();
$user['id'] = $_GET['id'];
$sth = $dbh->prepare("UPDATE user SET ban = 'Yes' where id = '".$user['id']."'");
$sth->execute([
    ':id' => $user['id'],
]);

echo '<a href="../admin">Вернуться в Административную Панель</a>';