<?php
use yii\helpers\Html;
use yii\helpers\Url;
?>
<h1>Добро пожаловать в Административную Панель</h1><br>
<ul>
    <li><?= Html::a('Управление пользователями', ['user/index']); ?></li>
    <li><?= Html::a('Управление категориями статей', ['category/index']); ?></li>
    <li><?= Html::a('Управление комментариями пользователей', ['comment/panel']); ?></li>
    <li><?= Html::a('Управление статьями', ['publication/panel']); ?></li>
    <li><?= Html::a('Управление комментариями забаненных пользователей', ['comment/panelban']); ?></li>
    <li><?= Html::a('Забанить определенных пользователей', ['user/panel']); ?></li>
    <li><?= Html::a('Разбанить определенных пользователей', ['user/panell']); ?></li>
</ul>