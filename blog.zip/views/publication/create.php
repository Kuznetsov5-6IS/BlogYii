<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Publication */

$this->title = 'Создание новой статьи';
$this->params['breadcrumbs'][] = ['label' => 'Мои статьи', 'url' => ['publication/my']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="publication-create">


    <?= $this->render('formcreate', [
        'model' => $model,
        'select' => $select,
    ]) ?>

</div>
