<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

$user = Yii::$app->user->identity->id;
/* @var $this yii\web\View */
/* @var $model app\models\Publication */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="publication-form">
    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_user')->hiddenInput(['value' => $user])->label(false) ?>

    <?= $form->field($model, 'img')->textInput(['placeholder' => 'standart.jpg']) ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>
    <?php
    $select = ArrayHelper::map($select, 'id', 'name');
    ?>
    <?= $form->field($model, 'id_category')->dropDownList($select) ?>

    <?= $form->field($model, 'text')->textArea(['maxlength' => 21000]) ?>

    <?= $form->field($model, 'start_date')->input('date') ?>

    <div class="form-group">
        <?= Html::submitButton('Создать статью', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
