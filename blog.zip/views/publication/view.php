<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Publication */
$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Все статьи', 'url' => ['publication/']];
$this->params['breadcrumbs'][] = $model->title;
\yii\web\YiiAsset::register($this);
?>
<div class="publication-view">

    <h1 class="view__title">Статья: <?= $model->title ?></h1>
    <p class="view__start__date">Дата публикации: <?= $model->start_date ?></p>
    <img class="view__img" src="../uploads/<?= $model->img ?>">
    <p class="view__text"><?= $model->text ?></p>
    <h4>Комментарии: </h4><br>
    <?php
    $dbh = new PDO('mysql:dbname=blog;host=localhost', 'root', 'root');
    $sth = $dbh->prepare("SET NAMES UTF8");
    $sth->execute();
    $sth = $dbh->prepare("SELECT * FROM comment JOIN publication ON comment.id_publication = '".$this->title."' JOIN user ON comment.id_user = user.id GROUP BY comment.comment ORDER BY date_placement DESC");
    $sth->execute();
    $comments = $sth->fetchAll();
    foreach($comments as $comment) {
        echo $comment['username'].' ('.$comment['date_placement'].') : '.$comment['comment'].'<br><hr>';
    }
    ?>
</div><br>
<a class="new__comment" href="../comment/create?id=<?= $model->id ?>">Добавить комментарий к статье</a>
<style>
.view__img {
    width: 100%;
    margin: 20px 0;
    border: 2px solid #000;
}
.publication-view {
    border: 1px solid #000;
    padding: 30px;
}
.view__text {
    font-size: 18px;
    letter-spacing: 1px;
    padding: 5px;
}
.view__start__date {
    font-size: 16px;
}
.new__comment {
    border: 1px solid #000;

    padding: 10px;
    width: 30%;
}
</style>
