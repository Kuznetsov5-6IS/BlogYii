<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\PublicationSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

?>
<form class="zaproc" action="publication/searchone" method="get">
    <input type="text" name="str" placeholder="Поиск...">
    <input type="submit" value="Поиск">
    <p>
</form>
<style>
    .zaproc {
        text-align: left;
    }
</style>
    <?php foreach($publications as $publication): ?>
        <?php echo '<div class="publication__index">'; ?>
            <?= '<img class="publication__img" src="uploads/'.$publication->img.'">'; ?>
            <?= '<h4 class="publication__title">'.$publication->title.'</h4>'; ?>
            <?= '<a href="publication/view?id='.$publication['id'].'" class="publication__text">Читать далее...</a>'; ?>
            <?php echo '</div>'; ?>
    <?php endforeach; ?>
    <style>
        .publication__index { transition: linear 1s background; border: 1px solid #000; width: 300px; height: 320px; display: inline-block; margin: 10px; background-color: #F0E68C; }
        .publication__img { width: 298px; height: 180px; }
        .publication__title { text-align: center; background-color: #D3D3D3; border: 1px solid #000; padding: 5px; }
        .publication__text { margin: 28%; font-size: 18px; color: #000; }
        .publication__text:hover { text-decoration: none; color: #fff; }
        .publication__index:hover { background: orange; border: 2px solid yellow; }
    </style>