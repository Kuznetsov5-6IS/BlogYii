<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\PublicationSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$user = Yii::$app->user->identity->id;
?>
<form class="zaproc" action="searchtwo" method="get">
    <input type="text" name="str" placeholder="Поиск...">
    <input type="submit" value="Поиск">
    <p>
</form>
<style>
    .zaproc {
        text-align: left;
    }
</style>
<p class="new__blog"><?= Html::a('Добавить новую статью', ['publication/create']) ?></p>
        <?php
        $dbh = new PDO('mysql:dbname=blog;host=localhost', 'root', 'root');
                $sth = $dbh->prepare("SET NAMES UTF8");
                $sth->execute();
                $sth = $dbh->prepare("SELECT * FROM `publication` where publication.id_user = '".$user."'");
                $sth->execute();
                $my = $sth->fetchAll();
                foreach($my as $m) {
                    echo '<div class="publication__index">'.
                    '<img src="../../web/uploads/'.$m['img'].'" class="publication__img">'
                    .'<h4 class="publication__title">'.$m['title'].'</h4>'
                    .'<a href="myview?id='.$m['id'].'" class="publication__text">Обзор статьи</a>'.
                    '</div>';
                }
        ?>
    <style>
        .publication__index { transition: linear 1s background; border: 1px solid #000; width: 300px; height: 320px; display: inline-block; margin: 10px; background-color: #F0E68C; }
        .publication__img { width: 298px; height: 180px; }
        .publication__title { text-align: center; background-color: #D3D3D3; border: 1px solid #000; padding: 5px; }
        .publication__text { text-align: center; font-size: 18px; margin: 30%; color: #000; }
        .publication__index:hover { background: orange; border: 2px solid yellow; }
        .publication__text:hover { color: #fff; text-decoration: none; }
        .new__blog { border: 1px solid #000; width: 20%; padding: 10px; }
    </style>

