<?php
namespace app\controllers;

use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use Yii;

class AdminController extends Controller {
    public function beforeAction($action) {
        if(Yii::$app->user->isGuest || Yii::$app->user->identity->admin != 1) {
            $this->redirect(['site/login']);
            return false;
        }

        if(!parent::beforeAction($action)) {
            return false;
        }

        return true;
    }


    public function actionIndex() {
        return $this->render('index');
    }
}