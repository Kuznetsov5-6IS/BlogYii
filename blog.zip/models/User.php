<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $username
 * @property int $password
 * @property string $firstname
 * @property string $lastname
 * @property string $birthday
 * @property int $ban
 *
 * @property Comment[] $comments
 * @property Publication[] $publications
 */
class User extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['birthday', 'username', 'password', 'lastname', 'firstname'], 'required', 'message' => 'Поле обязательно для заполнения'],
            [['username', 'password'], 'string', 'max' => 255],
            [['lastname', 'firstname'], 'string', 'max' => 50],
            ['username', 'match', 'pattern' => '/^[A-z0-9]{5}/u', 'message' => 'Используйте только английские буквы, цифры, 5 символов'],
            ['password', 'match', 'pattern' => '/^[A-Za-z0-9]{10}/u', 'message' => 'Введите более длинный пароль (10 символов)'],
            ['lastname', 'match', 'pattern' => '/^[A-Z][a-z]/u', 'message' => 'Введите свою фамилию с заглавной буквы, только английские буквы'],
            ['firstname', 'match', 'pattern' => '/^[A-Z][a-z]/u', 'message' => 'Введите свое имя с заглавной буквы, только английские буквы'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Пользователь',
            'password' => 'Пароль',
            'firstname' => 'Имя',
            'lastname' => 'Фамилия',
            'birthday' => 'Дата рождения',
            'ban' => 'Забанен',
        ];
    }

    /**
     * Gets query for [[Comments]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getComments()
    {
        return $this->hasMany(Comment::className(), ['id_user' => 'id']);
    }

    /**
     * Gets query for [[Publications]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPublications()
    {
        return $this->hasMany(Publication::className(), ['id_user' => 'id']);
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentity($id)
    {
        return self::findOne($id);
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return self::find()->andWhere(['username' => $username])->one();
    }

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */
    public function validatePassword($password)
    {
        return $this->password === $password;
    }
}
