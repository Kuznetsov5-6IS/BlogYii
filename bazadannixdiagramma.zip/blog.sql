-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 24 2021 г., 14:23
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `blog`
--

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(3, 'Горы'),
(4, 'Океан'),
(1, 'Спорт'),
(2, 'Экстрим');

-- --------------------------------------------------------

--
-- Структура таблицы `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_publication` int(11) NOT NULL,
  `comment` varchar(600) NOT NULL,
  `date_placement` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `comment`
--

INSERT INTO `comment` (`id`, `id_user`, `id_publication`, `comment`, `date_placement`) VALUES
(1, 2, 1, 'Привет! Суперский контент!', '2021-12-17'),
(2, 1, 2, 'Очень интересно и познавательно!', '2021-12-19'),
(3, 2, 1, 'Отличный блог!', '2021-12-20'),
(7, 1, 3, 'Класс!', '2021-12-24'),
(8, 1, 3, 'Однозначно лайк!', '2021-12-21'),
(9, 1, 4, 'Ставлю лайк!', '2021-12-26'),
(10, 2, 4, 'Слежу за вашим блогом каждый день!', '2021-12-23');

-- --------------------------------------------------------

--
-- Структура таблицы `publication`
--

CREATE TABLE `publication` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `id_category` int(11) NOT NULL,
  `text` varchar(21000) NOT NULL,
  `start_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `publication`
--

INSERT INTO `publication` (`id`, `id_user`, `img`, `title`, `id_category`, `text`, `start_date`) VALUES
(1, 2, 'mountains.jpg', 'Канадские горы', 3, 'Канадские Скалистые горы - цепь живописных гор на западе Канады, являющихся частью Американских Кордильер. Это система горных хребтов, ведущая от канадских прерий до Тихоокеанского побережья, давно стала символом дикой природы Северной Америки. Скалистые горы Канады включены в 1000 лучших достопримечательностей мира по версии нашего сайта.\r\n\r\nИх общая протяженность составляет около 1400 км. Наивысший пик - это гора Робсон (3954 м), а самая низка точка - река Лиард (305 м). В целом, в системе Скалистых гор (Rocky Mountains) берут начало многие полноводные и знаменитые реки. К ним относится река Колумбия, ставшая крупнейшим источником электроэнергии для всего континента. Природа Скалистых гор безупречно красива. Она включает в себя сотню хребтов, глубокие долины, живописные леса.\r\n\r\nПри этом на севере леса преимущественно горно-таежные, а на юге - сосновые. На территории Канадских Скалистых гор не менее пяти заповедных парков. Старейшим из них является Национальный парк Банф, а крупнейшим - Джаспер. Общая длина горной гряды более 3000 км. Климат преимущественно сухой прохладный, хотя местами встречаются даже полупустыни. Ландшафт Скалистых гор дополняют живописные озера, ленники и горячие источники.', '2021-12-17'),
(2, 1, 'jump.jpeg', 'Прыжки с парашютом', 2, 'Первое, главное и основное, что стоит помнить при совершении любого прыжка – это дисциплина. Если правильно и вовремя выполнять все напутствия инструктора, прыжок с парашютом становится не опаснее, чем переход дороги по регулируемому перекрестку. Поэтому внимательно слушайте инструктаж и выполняйте все задания, какими бы нелепыми или смешными они Вам ни казались. Постарайтесь не прикрывать свой страх и нервозность излишней говорливостью и дурачеством. Если Вы что-то не поняли или не расслышали – переспросите. И переспрашивайте до тех пор, пока не поймете или расслышите. \r\nВторое – адекватный контроль над состоянием собственного здоровья. Перед прыжком, скорее всего, Вас осмотрит врач. Померит давление, взвесит, оценит общее состояние. Но в остальном – Вы берете ответственность на себя. ', '2021-12-18'),
(3, 2, 'atlantic.jpg', 'Атлантический океан', 4, 'Атланти́ческий океа́н — второй по величине и глубине океан Земли после Тихого океана, расположенный между Гренландией и Исландией на севере, Европой и Африкой на востоке, Северной и Южной Америкой на западе и Антарктидой на юге. Площадь 91,66 млн км², из которых около 16 % приходится на моря, заливы и проливы.', '2021-12-19'),
(4, 2, 'velosport.jpg', 'Шоссейный велоспорт', 1, 'Шоссейный велоспорт – это олимпийский вид спорта, в котором велосипедисты соревнуются в преодолении дистанции на скорость на автомобильных дорогах общего пользования \r\nВелосипед был изобретен в России крепостным мастером Ефимом Михеевичем Артамоновым на одном из заводов Нижнего Тагила в 1800 году в день Пророка Ильи (20 июля (2 августа)). Артамонову не посодействовали в получении патента, и в 1817 году патент на первый в мире велосипед получил лесничий по имени Карл фон Драйс из Мангейма (Германия).', '2021-12-16');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `ban` varchar(255) NOT NULL DEFAULT 'No',
  `admin` int(11) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `firstname`, `lastname`, `birthday`, `ban`, `admin`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '2021-12-01', 'No', 1),
(2, 'timur', '1234567890', 'Timur', 'Kuznecov', '2003-11-28', 'No', 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Индексы таблицы `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_publication` (`id_publication`);

--
-- Индексы таблицы `publication`
--
ALTER TABLE `publication`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_category` (`id_category`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `publication`
--
ALTER TABLE `publication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comment_ibfk_3` FOREIGN KEY (`id_publication`) REFERENCES `publication` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `publication`
--
ALTER TABLE `publication`
  ADD CONSTRAINT `publication_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `publication_ibfk_3` FOREIGN KEY (`id_category`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
